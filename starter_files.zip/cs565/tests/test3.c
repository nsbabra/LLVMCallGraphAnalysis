int main() {
	int x, y, z;
	
	x = 12;
	y = x + 22;
	z = y + 33;	
}
